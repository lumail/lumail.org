
Rough Roadmap / Timeline
------------------------

* 0.01 - 0.17
   * Initial implementation of primitives and core.
* 0.18
   * Concentrating migrating MIME to GMime
* 0.19
   * Concentrating on UTF-8 input-handling.
* 0.20
   * Concentrating on UTF-8 output-correctness.
* 0.21
   * Consolidate the compose/reply code.  Aim to add `forward()` & `bounce()` primitives.
* 0.22+
   * Adding primitives as they become required/necessary & bugfixes.
