/**
 * version.h - Global version number specification.
 *
 * This file is part of lumail: http://lumail.org/
 *
 * Copyright (c) 2013 by Steve Kemp.  All rights reserved.
 *
 **
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 dated June, 1991, or (at your
 * option) any later version.
 *
 * On Debian GNU/Linux systems, the complete text of version 2 of the GNU
 * General Public License can be found in `/usr/share/common-licenses/GPL-2'
 */


/**
 * This version number is updated when we generate a tarball-release
 * via "make release".
 */

#ifndef    LUMAIL_VERSION
# define   LUMAIL_VERSION "0.19"
#endif  /* LUMAIL_VERSION */
