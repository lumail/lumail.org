# Lumail 2

Lumail2 is a console-based email client that operates upon Maildir
hierarchies.

The implementation of the client consists of both a C++ core and a
layer of Lua scripting. This documentation describes the C++ details.

## Lua API

The Lua API is described seperately in the file [API.md](API.md), which is
included within the repository and which is
[also available online](https://luamil.org/api/).
