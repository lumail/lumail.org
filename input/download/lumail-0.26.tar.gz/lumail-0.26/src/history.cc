/**
 * history.cc - History wrapper for prompt-input
 *
 * This file is part of lumail: http://lumail.org/
 *
 * Copyright (c) 2013-2014 by Steve Kemp.  All rights reserved.
 *
 **
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2 dated June, 1991, or (at your
 * option) any later version.
 *
 * On Debian GNU/Linux systems, the complete text of version 2 of the GNU
 * General Public License can be found in `/usr/share/common-licenses/GPL-2'
 */


#include <string.h>
#include <fstream>

#include "debug.h"
#include "history.h"


/**
 * Instance-handle.
 */
CHistory *CHistory::pinstance = NULL;


/**
 * Get access to our singleton-object.
 */
CHistory *CHistory::Instance()
{
    if (!pinstance)
        pinstance = new CHistory;

    return pinstance;
}


/**
 * Constructor - This is private as this class is a singleton.
 */
CHistory::CHistory()
{
}


/**
 * Return the size of the history.
 */
int CHistory::size()
{
    return( m_history.size() );
}


/**
 * Get the Nth piece of history.
 */
UTFString CHistory::at( size_t offset )
{
    /**
     * Ensure the history offset is correctly bound.
     */
    assert( offset < m_history.size() );

    return( m_history.at( offset ) );
}



/**
 * Return the first string which matches the given expression.
 */
UTFString CHistory::matching( UTFString input )
{

#ifdef LUMAIL_DEBUG
    std::string dm = "CHistory::matching(";
    dm += input;
    dm += ");";
    DEBUG_LOG( dm );
#endif

    for( int i = size()-1; i >= 0; i-- )
    {
        UTFString entry = at( i );

#ifdef LUMAIL_DEBUG
    std::string dm = "CHistory::matching - discarded(";
    dm += entry;
    dm += ");";
    DEBUG_LOG( dm );
#endif

        if ( (!entry.empty()) &&
             (strstr( entry.c_str(), input.c_str() ) != NULL ) )
        {
            return( entry );
        }
    }
    return "";
}


/**
 * Add a new string to the history.
 */
void CHistory::add( UTFString entry)
{
    /**
     * Don't add empty entries.
     */
    if ( entry.empty() )
        return;

    m_history.push_back(entry);
    assert( m_history.size() > 0 );

    /**
     * If we've got a filename append the history.
     */
    if ( ! m_filename.empty() )
    {
        std::fstream fs;
        fs.open ( m_filename,  std::fstream::out | std::fstream::app);
        fs << entry << "\n";
        fs.close();
    }
}


/**
 * Clear the history.
 */
void CHistory::clear()
{
    m_history.clear();
    assert( m_history.size() == 0 );
}

/**
 * Set the file.
 */
void CHistory::set_file( UTFString filename)
{
    /**
     * Clear the current history.
     */
    m_history.clear();

    /**
     * Save the filename
     */
    m_filename = filename;

    /**
     * Load the prior history
     */
    std::ifstream input ( m_filename );
    if ( input.is_open() )
    {
        while( input.good() )
        {
            std::string line;
            getline( input, line );

            if ( ! line.empty() )
                m_history.push_back( line );
        }
        input.close();
    }
}
