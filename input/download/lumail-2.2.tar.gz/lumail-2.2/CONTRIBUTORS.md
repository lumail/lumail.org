# Author

The main author this project is Steve Kemp <steve@steve.org.uk>

# Contributors

The following people helped contribute code to the project:

* Chris Emerson
* Raphaël Rigo

# Special Thanks

Special thanks to people who were patient and who helped debug
problems, flaws, and bugs:

* RquasiR
